--
-- Greenplum Database database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ambcode; Type: TABLE; Schema: public; Owner: msushkov; Tablespace: 
--

CREATE TABLE ambcode (
    lower text
) DISTRIBUTED BY (lower);


ALTER TABLE public.ambcode OWNER TO msushkov;

--
-- Data for Name: ambcode; Type: TABLE DATA; Schema: public; Owner: msushkov
--

COPY ambcode (lower) FROM stdin;
al
ne
mo
sd
id
vi
sc
tn
in
az
il
ms
ca
mt
va
de
ky
ar
co
ga
md
me
nc
pa
mn
\.


--
-- Greenplum Database database dump complete
--

