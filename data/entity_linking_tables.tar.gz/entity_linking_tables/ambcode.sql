--
-- Greenplum Database database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;


SET default_tablespace = '';


CREATE TABLE ambcode (
    word1 text
);


COPY ambcode (word1) FROM stdin;
AL
GA
MD
ME
CA
NC
DE
MN
MO
CO
SD
NE
ID
VI
PA
SC
IN
AZ
IL
VA
KY
TN
AR
MT
MS
\.

