--
-- Greenplum Database database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';


CREATE TABLE entity_feature_bing_query (
    query1 text,
    eid2 text,
    rank3 text
);


COPY entity_feature_bing_query (query1, eid2, rank3) FROM stdin;
armenia	m.0jgx	1
columbia	m.01w5m	2
amerie	m.039byr	1
alan jackson	m.0drwgh	4
charlie dressen	m.06v265	1
butte	m.0c3jhm	2
az	m.0vmt	1
bobby anderson	m.047crcq	2
cabo	m.02dfgb	1
angelina jolie	m.0f4vbz	1
angelina jolie	m.0c6qh	3
bill gates	m.0dmp4	4
amy goodman	m.020m38	1
barnhill	m.0z2j3	1
austin	m.0vzm	1
australia	m.026qnh6	3
angelina jolie	m.01mqgf	4
acorn	m.03q7mt	2
baluchistan	m.0cbjfh	3
angelina jolie	m.046qq	2
australia	m.0chghy	1
al qaeda	m.0v74	1
argentina	m.0jgd	1
davos	m.0174w5	7
aarti agarwal	m.027gds6	1
bill gates	m.027z0k	7
argentina	m.02bh_v	2
alan jackson	m.02q34zp	5
alan jackson	m.03cm7hm	3
bengkulu	m.02hxvm1	3
ampas	m.09xwz	1
belize city	m.0177xm	1
bmg	m.01q940	1
angelina jolie	m.01fh9	5
brown institute	m.04_blz	1
barbara streisand	m.03f2_rc	1
brian williams	m.030p0z	1
aaron glantz	m.027gx6f	1
camilla al fayed	m.051g0	1
berkshire hathaway	m.01tmng	1
bill gates	m.05tkm	5
beijing	m.01914	1
bob hope	m.015cbq	1
bill gates	m.010rmb	9
alan jackson	m.016c8l	1
colorado	m.01vsl	4
democratic party	m.07wbk	2
armenia	m.0xrg	5
berkeley	m.02zd460	2
chester	m.01423b	1
cameroon	m.03yl2t	3
detroit	m.02dtg	1
bruce lee	m.0fdb3	3
charlie swift	m.0c80nx	1
austin	m.01mz2x	4
argentina	m.01ly5m	4
british broadcasting corporation	m.0g5lhl7	1
britney spears	m.01hm56_	5
brian williams	m.0t67h	3
bengkulu	m.02bdkx	1
constantinople	m.03zyym	3
bisher al-rawi	m.0803h9	1
chinese foreign ministry	m.02626pc	2
bill clinton	m.025st0_	2
christine todd whitman	m.019qv6	1
berkeley	m.01jr6	1
baluchistan	m.0fkf9j	5
bago	m.06ncrh	2
duisburg	m.09ggxl	6
chile	m.01p1v	1
brian williams	m.0djc_l	2
austin	m.0mpzm	2
baltimore city	m.094jv	1
beijing	m.01qmjm	2
cancun	m.01q98m	1
annapolis	m.0fvwg	1
bobby fischer	m.06k9jc	1
dolly parton	m.02s9k_	3
balewa muhammed	m.02z0ckz	1
chad johnson	m.03tnlt	1
connecticut	m.0f1sm	4
cameroon	m.01nln	1
boston college	m.01jsk6	1
degeneres	m.01pcz9	2
brian williams	m.0dknp2	6
canton	m.0z1vw	2
bobby fischer	m.02rhjj	7
brian williams	m.065lsm	4
cyndi	m.0bgjq1	5
armani exchange	m.03wr6g	1
dolly parton	m.02f1c	1
fdic	m.015wpt	1
bill moyers	m.05x0zf5	1
bruce lee	m.02rzb	5
christy	m.08znxc	1
flint	m.0m2rv	5
edmonton	m.06psyf	2
bucharest	m.096gm	1
degeneres	m.0528kc	3
buffalo	m.019fh	1
burma	m.04xn_	1
charles larson	m.0kt7y8	2
bruce lee	m.05_pzw	4
carton carroll	m.02ps_y6	2
bmg	m.01kpth	2
degeneres	m.043x92	4
britney spears	m.01hm5fk	4
donald trump	m.0429hq	4
chad johnson	m.049d_	4
dekalb	m.0s61l	1
bill gates	m.017nt	1
guayaquil	m.01fknt	1
barbara streisand	m.01zg98	4
ga	m.0d0x8	1
hdfc	m.025tzgk	1
canton	m.01cd5l	5
bristol	m.095l0	1
democratic party	m.0d075m	1
calcutta	m.03nx8jd	3
carton carroll	m.02q868l	1
bill clinton	m.0157m	1
cambridge	m.07tg4	2
gwen stefani	m.01n9zh9	5
bobby fischer	m.0h09p	2
coppola	m.01_f_5	5
degeneres	m.01gbbz	1
cesaria evora	m.0j_gr	1
bristol	m.0gk7z	3
edmonton	m.01pfwp	4
coppola	m.0ksv3d	2
chris breezy	m.07ss8_	2
bruce lee	m.099d4	1
ca	m.01n7q	1
dartmouth	m.02bqy	1
borders	m.0mdv8	1
fonda	m.066z5r	3
korea	m.05b7q	3
britney spears	m.015f7	1
cecilia malmstrom	m.054w2k	1
free trade union	m.095q8	5
galilee	m.0j1t3	2
fonda	m.0cj8x	6
butte	m.01m2v2	4
duisburg	m.0ps1q	1
chen shu-bian	m.0fbn3	1
caa	m.020sn8	1
chris breezy	m.01rph40	3
chrysler	m.01_bp	1
colorado	m.018qjq	3
bruce campbell	m.01h8f	1
duisburg	m.03c_t05	3
dolly parton	m.01l1_1	5
gloucester	m.0hc8h	1
douglas adams	m.0282x	1
edmonton	m.0nlh7	1
calcutta	m.0cvw9	1
joe biden	m.012gx2	1
bengkulu	m.0gc8cf	2
jerusalem post	m.01978x	1
leann rimes	m.07s61nv	2
c. michael foale	m.02cwy9	1
dmk	m.024z18	1
denver	m.02cl1	1
chad johnson	m.02zdgb	6
chinese foreign ministry	m.0c5lv5	1
cleveland	m.01sn3	1
carlyle group	m.011vwm	1
ken starr	m.0grkx	1
bob dole	m.0fhkx	1
cyndi	m.04kcym	6
fort worth	m.0f2s6	1
chris johnson	m.03d753s	1
carnoustie	m.03kb5r	2
fonda	m.07hkd	4
florida state	m.01jq0j	1
george bush	m.034ls	6
colorado city	m.0qpvx	1
cambridge	m.0978r	1
hungary	m.01zd7d	4
donald trump	m.0cqt90	1
guinea	m.02kcz	4
las vegas	m.0cv3w	1
britney spears	m.03cn3v1	3
coppola	m.02vyw	1
george town	m.015806	2
george jones	m.01d67x	3
george burns	m.07z81x	3
chile	m.033nzk	5
environmental protection agency	m.0g0lh	1
david jones	m.02fl5v	2
connecticut	m.01x73	1
fulton	m.06j4s	1
george town	m.01c60h	1
columbia	m.06_sn	1
colorado	m.01n4w	1
hewlett packard	m.03mnk	1
estonia	m.02kmm	1
gwen stefani	m.014qv7	4
indiana university	m.01qrb2	1
green party	m.07k5l	1
honolulu	m.02hrh0_	1
karnataka	m.049lr	1
bill clinton	m.0d06m5	4
john rich	m.01hk70n	3
national students union	m.01d62s	2
malaga	m.01978d	1
george bush	m.0193q3	3
ed zwick	m.04g3p5	1
chen pao-chung	m.04md0g	1
connecticut	m.0m2fr	5
eg white	m.01nxpn	1
chad johnson	m.03tnlt	2
lester brown	m.05jwm0	1
carnoustie	m.07gv8l	1
delisha thomas	m.02pj_7x	1
hanoi	m.0fnff	1
dublin	m.02cft	1
davos	m.0pbgk	1
gao	m.01c8jp	1
george jones	m.01hb9p	1
georgia	m.0d0kn	5
cornell	m.01w3v	1
columbus	m.01pwz	1
johnny cash	m.01h5f8	3
estonia	m.07r_p	4
gwen stefani	m.016fmf	3
lily allen	m.04cy6hp	4
bruce lee	m.01dkgz	2
degeneres	m.01vhb0	5
gwen stefani	m.026d7vt	2
idbi bank	m.090whv	1
glenn beck	m.0264n4	1
lyon	m.03w7kx	2
george burns	m.01t94_1	1
fonda	m.0h1mt	1
continental airlines	m.0sy5v	1
guinea	m.03676	1
john rich	m.02rqtz2	4
daily mail	m.0180v2	1
hawaii	m.03gh4	1
hungary	m.03gj2	1
gao	m.04mm6w	2
jackman	m.03h_9lg	1
jeff daniels	m.0372kf	1
irvine	m.0d7k1z	1
islamabad	m.0248y5	2
magnum	m.03ylyv	4
fico	m.02cgrf	1
merrill	m.01kb4x	1
nebraska	m.0chrx	3
north carolina	m.0fvyg	3
hanover	m.013_6w	5
nepal	m.04cx5	3
cyndi	m.01wf86y	1
corey johnson	m.06znt5	1
el salvador	m.02k8k	1
clarisa fernandez	m.0ddvyt	1
mark wills	m.03yfwjb	3
columbus	m.0wfd3	6
george bush	m.04g8d	5
jokela	m.03cv7d7	1
ivory coast	m.04ddyt	4
jerry springer	m.0zxgh	6
george bush	m.09b6zr	2
hollywood	m.050ctv	2
jackman	m.05r751	2
hawaii	m.09wyd	5
faa	m.02_hj	1
kid rock	m.01vw20_	1
jessica simpson	m.0c7xjb	1
kunduz	m.01g8_p	1
national union of mine workers	m.0djx71	3
bz	m.03y2d0	1
hanoi	m.02y_w3c	7
indonesia	m.03ryn	1
jordin	m.09k2t1	1
hennepin county	m.0nhmw	1
marc anthony	m.02pr1v2	5
gloucester	m.0tz01	6
hollywood	m.035zpq	4
davos	m.027rmps	4
kenya	m.05d49	2
keith anderson	m.07cgrf	1
donald trump	m.061wfm	3
justin timberlake	m.05n3l7	5
johns hopkins	m.09kvv	1
jonathan edwards	m.0dpv5	1
leann rimes	m.06xt6v	4
led zeppelin	m.0pkyh	4
jackman	m.03nsp7q	5
leo dicaprio	m.04kdfm	3
manchester	m.0kqb0	2
john gibson	m.04myhq	1
montana	m.0x44q	4
o2	m.03fhtm	4
thomas jefferson	m.07cbs	3
mark wills	m.03yfv1f	4
oregon	m.02frhbc	2
donald trump	m.04hfnv	2
daytona beach	m.0rsjf	1
jamal williams	m.09gjr4	1
geneva	m.03902	1
mccartney	m.01wk4d2	4
costa rica	m.01p8s	1
islamabad	m.0dhd5	1
leann rimes	m.01fkxr	1
kashmir	m.048bf_	3
niger	m.0fqfs	9
gordon brown	m.03f77	1
laguna beach	m.048wfw	1
korea	m.02hwhyv	5
honiara	m.09_ryj	6
ferndale	m.0nr3p	1
manhasset	m.0y2r_	1
johnny cash	m.098bm9	5
louisiana	m.0tl6d	5
nepal	m.01tgny	8
canton	m.06zw6t	4
heidi klum	m.01pctb	1
jerry springer	m.01v0432	1
mana	m.03b77h	6
mark twain	m.014635	1
michel gondry	m.02l7nd	1
korea national oil corp	m.03h2z4h	1
korea	m.048fz	1
estonia	m.02s2l	7
led zeppelin	m.04k05	1
national development and reform committee	m.02qdypp	6
guinea	m.0fn8p	3
kid rock	m.01kcl94	5
liverpool	m.04lh6	1
managua	m.02y8v7	2
led zeppelin	m.015pvx	3
magnum	m.02mc3x	5
missouri	m.06wxw	2
manchester	m.01nhwy	4
maryland	m.0tt6k	3
john rich	m.07wqk_	1
mtr	m.01nj0j	1
preston	m.09ybgf	3
us airways	m.01qmg5	1
nazareth	m.02t5l1	6
san francisco	m.01l4xk	3
dt	m.0fpnjr	6
general electric	m.03bnb	1
kid rock	m.01ws5ht	4
gwen stefani	m.016fnb	1
mccartney	m.03j24kf	1
george burns	m.01whz6_	2
liverpool	m.04ltf	2
led zeppelin	m.01vsyg9	5
larry craig	m.021pfw	1
nwf	m.04z44v	1
justin timberlake	m.0j1yf	1
michael bloomberg	m.09pfj	1
kroq	m.017drb	1
houston	m.03l2n	1
george burns	m.06rj2f	5
mayawati	m.02psg0	1
matthaeus	m.01ttk9t	1
nsa	m.05htt	1
nepal	m.02wx1kv	9
donald trump	m.0dzqp5	5
jordin	m.09k2t1	3
jordin	m.0bb85cr	5
memphis	m.0c_m3	1
mccartney	m.01j7tc9	6
national development and reform committee	m.02qdypp	1
lansing	m.04pry	1
matt farrell	m.07cjqy	1
goldman	m.01xdn1	1
lehman brothers japan	m.078t6w	3
nepal	m.016zwt	1
houston	m.01vpt5	2
lehman brothers japan	m.03lplr	1
milan	m.011v3	6
miami	m.0rnmy	2
memphis	m.02qxwz2	4
malaysia	m.09pmkv	1
montreal	m.0fk8v	5
mark wills	m.01m3cwg	1
merle haggard	m.01jpfr8	3
korea	m.06qd3	2
north waziristan agency	m.048z8c	1
ritchie	m.02933	1
willie nelson	m.0137n0	1
nazareth	m.05fz3	1
sarasota	m.0rrt1	2
free trade union	m.07gkc2	2
maruti udyog	m.042ggk	1
new brunswick	m.059s8	1
kashmir	m.0djgt	8
oregon	m.0k62f	4
grand national	m.02r7lj6	6
louisiana	m.0f2tj	2
new yorker	m.07q5n	1
mexico city	m.04sqj	1
reliance industries	m.0242c6	1
montreal	m.0jplb	3
mtr	m.046w7v	5
lake tahoe	m.011ll4	1
john rich	m.01qj8sj	2
georgia tech	m.0f1nl	1
national union of mine workers	m.025n0_	1
mccartney	m.01dwcv	5
palestine	m.0h44w	6
order and justice party	m.02kzyq	7
haarp	m.07jyq	2
jp morgan chase	m.01hlwv	1
lyon	m.0dprg	1
merle haggard	m.01ww2fs	1
nlf	m.0hw29	1
nebraska	m.05fhy	1
montreal	m.05fyrr	2
mongolia	m.04w8f	1
haarp	m.03cnf_5	6
morrocco	m.022b_	4
seth rogan	m.02825nf	4
qatar	m.046zk0	5
johannesburg	m.0g284	1
kenya	m.019rg5	1
marc anthony	m.01wv9p	1
ny times	m.07k2d	1
pittsburgh	m.01jssp	3
nj	m.05fjf	1
nepal	m.05bwc	6
norman	m.0z4_0	1
ivory coast	m.0fv4v	1
oklahoma	m.013kcv	5
indonesia	m.044rv	7
magnum	m.06rfd4	2
qatar	m.029tr_	4
mike russell	m.03bzbx	1
new brunswick	m.0xpp5	6
vanilla ice	m.01vxqyl	1
newcastle	m.0j7ng	1
mgm	m.0g1rw	1
nazareth	m.08cgd0	10
lasalle bank corp	m.07k6g8	1
ore	m.02npvl	6
robert menendez	m.033d3p	1
un security council	m.07vnr	1
uc	m.07vgd	1
johnny cash	m.03h_fk5	1
montreal	m.052p7	1
mark twain	m.03q5b	4
pacific design center	m.02pt6k9	1
ringo starr	m.01vrnsk	1
nra	m.0j6f9	1
pittsburgh	m.068p2	1
ohio	m.01smm	4
johnny cash	m.04w8rf	4
oman telecommunications company	m.02686nz	1
justin timberlake	m.0320jz	3
minneapolis	m.0fpzwf	1
saddam hussain	m.01c3y8	3
pam anderson	m.08drs2	3
oxford	m.05l5n	1
warren buffett	m.03llg9	6
korea	m.048n7	6
nlf	m.0hw29	2
philadelphia	m.0dclg	1
sheehan	m.0744x5	1
santos	m.03nw8m	5
pvdsa	m.04gnr5	1
san jose	m.0f04v	1
pam anderson	m.05zhsb	2
judy shepard	m.0nx9_	6
petra nemcova	m.033zwr	1
knowles	m.01mpq7s	1
peace corps	m.019574	1
sinaloa	m.01gfkk	1
suzuki	m.02ws0w	1
preston	m.0m7dd	1
state department	m.07vsl	1
nepal	m.02rhmtd	5
new brunswick	m.02w70	4
leann rimes	m.02vp0p6	3
reserve bank	m.02gzw1	1
spain	m.06mkj	1
neil gaimen	m.05hjxf	4
teheran	m.0359x4	3
sasha	m.01w8s4d	1
new brunswick	m.074r0	2
oklahoma	m.0fvzg	2
ku klux klan	m.048qr	1
richmond	m.0dzt9	1
harvard university	m.03ksy	1
marc anthony	m.02rrrp1	3
qatar	m.0f2yw	3
pam anderson	m.0fp0mk	4
ucla medical center	m.04fghh	1
rachael ray	m.031618	1
nazareth	m.01vtkx	3
leo dicaprio	m.0dvmd	1
liberal constitutional party	m.02439x	1
hanover	m.03pbf	1
public security police	m.01ncvk	1
miami	m.0f2v0	1
maryland	m.0dzn7	2
qatar	m.0697s	1
uc irvine	m.0c5x_	1
travis tritt	m.01k_r5b	1
south dakota	m.013l6l	3
stephen king	m.07j6g	4
mccartney	m.01f761	3
sheehan	m.03jd4n	6
warsaw	m.0c732h	5
wesleyan university	m.01k2wn	1
stella	m.071mw	2
tamil tigers	m.04q9w	1
pep boys	m.030p_p	1
justin timberlake	m.01mzt36	4
sarasota	m.0rry7	4
malaysia	m.049d1	3
rcmp	m.0j05f	1
st louis	m.01n579	2
us senate	m.07t58	1
sears	m.01pkvx	1
usa	m.0fw2y	2
pam anderson	m.0c61rf	5
wellington	m.02c4s	2
milan	m.0947l	1
teheran	m.01ct02	6
terracotta army	m.0131pq	1
newcastle	m.0fvly	6
teheran	m.0ftlx	1
secret service	m.0fynw	1
o2	m.047t9qn	3
pam anderson	m.05r5w	1
lily allen	m.0czkbt	1
saddam hussain	m.079dy	1
indiana	m.03b12	5
nebraska	m.04gxf	4
venice	m.07_pf	1
san francisco	m.0d6lp	1
umno	m.01__z0	1
sarasota	m.0rrwt	1
stephen king	m.06pnq	1
managua	m.0fqbf	1
lynwood	m.0r0ls	1
haren	m.04qzsg	2
tia	m.07s82	1
oklahoma	m.0k92j	3
new york stock exchange	m.05drh	1
usa	m.09c7w0	1
poland	m.05qhw	1
wells fargo	m.01kdws	1
zurich	m.08966	1
randalls	m.05_94s	1
yorkshire	m.094vy	1
ruffalo	m.035rnz	1
sanford	m.02c6ck	1
shabazz	m.02z_zj	5
refoundation communists	m.01zyx7	1
nazareth	m.01jkmfs	8
seth rogan	m.05txrz	1
marvel entertainment inc.	m.0c_j5d	1
sherpa	m.01gr8h	1
woody allen	m.01cpqk	4
washington university	m.0g2jl	1
south dakota	m.0_rwf	4
woody allen	m.081lh	1
pt excelcomindo pratama	m.047rwn1	1
stella	m.06b7_b	1
neil gaimen	m.05jm7	1
the times	m.09rkd	1
mobile	m.058cm	1
zac	m.06wm0z	1
north carolina	m.0fsb8	2
world health organisation	m.0840w	1
tustin	m.0r2q1	1
sarasota	m.0rrvf	3
willie nelson	m.07s7kjg	2
the associated press	m.0cv_2	1
washington times	m.07qhs	1
rangoon	m.0fs54	1
orient-express	m.015m8_	3
warren buffett	m.0d2gsm	3
thomas edison	m.07bty	1
new line cinema	m.024rgt	1
thomas jefferson	m.07cbs	1
tamil tigers	m.029ccy	2
paul walker	m.01kgxf	1
wellington	m.0853g	1
richard clarke	m.02nh4b	1
travis tritt	m.01k_r48	3
willie nelson	m.04hw0c	5
ringo starr	m.076d59	4
usc	m.07vwp	1
warren buffett	m.01d_ys	1
north atlantic treaty organization	m.05j8g	5
saks fifth avenue	m.079bt	1
verizon	m.07_dn	1
william ayers	m.05b2cz	1
oxford	m.07tgn	2
warsaw	m.081m_	1
sao paulo	m.022pfm	1
walmart	m.0841v	1
william shakespeare	m.081k8	1
san diego	m.071vr	1
spain	m.02w64f	3
world trade organisation	m.085h1	1
ybor city	m.03cbsk	1
santos	m.027j0rt	4
msn	m.0198jf	1
slovenia	m.03ys48	4
manchester	m.052bw	1
wainwright	m.01hsrn	2
scarsdale	m.01rkbc	1
nepal	m.0h0t4	7
union city	m.0xn99	2
rob marshall	m.02hc7q	1
woody allen	m.01tzw_	3
william shakespeare	m.0bdc4	5
warren buffett	m.03cjb43	5
tamil tigers	m.07qct	5
teheran	m.06sdvc	4
national union of mine workers	m.025n0_	2
morrocco	m.04wgh	1
niger	m.05cc1	1
western union	m.01bfgd	1
rolling thunder	m.01gy3j	1
thomas jefferson	m.02z_j3	4
pakistan	m.05sb1	1
thomas jefferson	m.0px8y	2
saddam hussain	m.023ygx	9
seth rogan	m.047m6mv	5
santa clarita	m.0fl3w4	1
washington dc	m.0rh6k	1
yorkshire	m.01_gx_	2
new york police department	m.01lvn4	1
national science foundation	m.014psl	1
north atlantic treaty organization	m.059dn	1
nivea hamilton	m.01mv4h9	1
national transportation board	m.05h31	1
pisco	m.02wprs	3
orient-express	m.0c2h62	2
new mexico	m.0djd3	2
riyadh	m.0dlm_	1
santos	m.019lxm	1
norfolk	m.0fwc0	1
slovenia	m.06t8v	1
va	m.07z1m	1
ostrava	m.07g4fk	6
teheran	m.02vr30	9
union city	m.0qy1f	1
time magazine	m.07s52	1
tom coburn	m.03wnjr	1
\.

