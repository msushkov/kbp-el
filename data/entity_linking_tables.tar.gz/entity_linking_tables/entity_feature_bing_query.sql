--
-- Greenplum Database database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: entity_feature_bing_query; Type: TABLE; Schema: public; Owner: msushkov; Tablespace: 
--

CREATE TABLE entity_feature_bing_query (
    query1 text,
    eid2 text,
    rank3 text
);



--
-- Data for Name: entity_feature_bing_query; Type: TABLE DATA; Schema: public; Owner: msushkov
--

COPY entity_feature_bing_query (query1, eid2, rank3) FROM stdin;
Colorado	E_m_01n4w	1 
Cambridge	E_m_0978r	1 
Hanoi	E_m_0fnff	1 
Costa Rica	E_m_01p8s	1 
GA	E_m_0d0x8	1 
Burma	E_m_04xn_	1 
Annapolis	E_m_0fvwg	1 
CA	E_m_01n7q	1 
Calcutta	E_m_0cvw9	1 
Philadelphia	E_m_0dclg	1 
Spain	E_m_06mkj	1 
Minneapolis	E_m_0fpzwf	1 
Cameroon	E_m_01nln	1 
Norfolk	E_m_0fwc0	1 
Miami	E_m_0f2v0	1 
Bristol	E_m_095l0	1 
NJ	E_m_05fjf	1 
New Mexico	E_m_0djd3	2 
Gwen Stefani	E_m_016fnb	1 
Indonesia	E_m_03ryn	1 
Estonia	E_m_02kmm	1 
Baltimore City	E_m_094jv	1 
Constantinople	E_m_03zyym	3 
AZ	E_m_0vmt	1 
Detroit	E_m_02dtg	1 
Barnhill	E_m_0z2j3	1 
Flint	E_m_0m2rv	5 
SAN FRANCISCO	E_m_0d6lp	1 
Berkeley	E_m_01jr6	1 
Bill Moyers	E_m_05x0zf5	1 
Irvine	E_m_0d7k1z	1 
Bucharest	E_m_096gm	1 
Beijing	E_m_01914	1 
Gloucester	E_m_0hc8h	1 
Lake Tahoe	E_m_011ll4	1 
El Salvador	E_m_02k8k	1 
Cleveland	E_m_01sn3	1 
Daytona Beach	E_m_0rsjf	1 
Edmonton	E_m_0nlh7	1 
SAN DIEGO	E_m_071vr	1 
Cancun	E_m_01q98m	1 
ACORN	E_m_03q7mt	2 
Denver	E_m_02cl1	1 
Bill Clinton	E_m_0157m	1 
Morrocco	E_m_04wgh	1 
Colorado	E_m_018qjq	3 
Cambridge	E_m_07tg4	2 
Hanoi	E_m_02y_w3c	7 
Amerie	E_m_039byr	1 
William Ayers	E_m_05b2cz	1 
Aaron Glantz	E_m_027gx6f	1 
Warsaw	E_m_081m_	1 
Las Vegas	E_m_0cv3w	1 
Calcutta	E_m_03nx8jd	3 
Richard Clarke	E_m_02nh4b	1 
Spain	E_m_02w64f	3 
Oregon	E_m_02frhbc	2 
Cameroon	E_m_03yl2t	3 
Michael Bloomberg	E_m_09pfj	1 
Miami	E_m_0rnmy	2 
Bristol	E_m_0gk7z	3 
Donald Trump	E_m_0cqt90	1 
Union City	E_m_0qy1f	1 
Gwen Stefani	E_m_026d7vt	2 
Indonesia	E_m_044rv	7 
Estonia	E_m_07r_p	4 
Eg White	E_m_01nxpn	1 
Niger	E_m_05cc1	1 
Indiana	E_m_03b12	5 
Qatar	E_m_0697s	1 
Canton	E_m_0z1vw	2 
Harvard University	E_m_03ksy	1 
SAN FRANCISCO	E_m_01l4xk	3 
Berkeley	E_m_02zd460	2 
Merrill	E_m_01kb4x	1 
Malaysia	E_m_09pmkv	1 
Yorkshire	E_m_094vy	1 
Beijing	E_m_01qmjm	2 
Gloucester	E_m_0tz01	6 
Palestine	E_m_0h44w	6 
New Yorker	E_m_07q5n	1 
North Carolina	E_m_0fsb8	2 
Islamabad	E_m_0dhd5	1 
Edmonton	E_m_06psyf	2 
Ritchie	E_m_02933	1 
Michel Gondry	E_m_02l7nd	1 
Chile	E_m_01p1v	1 
Honolulu	E_m_02hrh0_	1 
Bill Clinton	E_m_025st0_	2 
Morrocco	E_m_022b_	4 
Colorado	E_m_01vsl	4 
Columbia	E_m_06_sn	1 
Houston	E_m_03l2n	1 
Wells Fargo	E_m_01kdws	1 
AMPAS	E_m_09xwz	1 
Johnny Cash	E_m_03h_fk5	1 
Warsaw	E_m_0c732h	5 
Fonda	E_m_0h1mt	1 
David Jones	E_m_02fl5v	2 
Cornell	E_m_01w3v	1 
Coppola	E_m_02vyw	1 
Oregon	E_m_0k62f	4 
NRA	E_m_0j6f9	1 
Australia	E_m_0chghy	1 
Montana	E_m_0x44q	4 
Memphis	E_m_0c_m3	1 
Donald Trump	E_m_04hfnv	2 
Union City	E_m_0xn99	2 
Gwen Stefani	E_m_016fmf	3 
GAO	E_m_01c8jp	1 
Estonia	E_m_02s2l	7 
Sheehan	E_m_0744x5	1 
Niger	E_m_0fqfs	9 
Louisiana	E_m_0f2tj	2 
Qatar	E_m_0f2yw	3 
Canton	E_m_06zw6t	4 
DeKalb	E_m_0s61l	1 
Ringo Starr	E_m_01vrnsk	1 
Aarti Agarwal	E_m_027gds6	1 
Lester Brown	E_m_05jwm0	1 
Malaysia	E_m_049d1	3 
Yorkshire	E_m_01_gx_	2 
Kenya	E_m_019rg5	1 
Sarasota	E_m_0rrwt	1 
Christy	E_m_08znxc	1 
RCMP	E_m_0j05f	1 
North Carolina	E_m_0fvyg	3 
Islamabad	E_m_0248y5	2 
Edmonton	E_m_01pfwp	4 
Carlyle Group	E_m_011vwm	1 
Ruffalo	E_m_035rnz	1 
Chile	E_m_033nzk	5 
Karnataka	E_m_049lr	1 
Bill Clinton	E_m_0d06m5	4 
South Dakota	E_m_013l6l	3 
New Brunswick	E_m_059s8	1 
Columbia	E_m_01w5m	2 
Houston	E_m_01vpt5	2 
Manchester	E_m_052bw	1 
Bobby Anderson	E_m_047crcq	2 
Johnny Cash	E_m_01h5f8	3 
Chris Johnson	E_m_03d753s	1 
Fonda	E_m_066z5r	3 
LeAnn Rimes	E_m_01fkxr	1 
Western Union	E_m_01bfgd	1 
Coppola	E_m_0ksv3d	2 
Jackman	E_m_03h_9lg	1 
Cabo	E_m_02dfgb	1 
Australia	E_m_026qnh6	3 
Nebraska	E_m_05fhy	1 
Memphis	E_m_02qxwz2	4 
Donald Trump	E_m_061wfm	3 
Florida State	E_m_01jq0j	1 
Gwen Stefani	E_m_014qv7	4 
GAO	E_m_04mm6w	2 
Korea	E_m_048fz	1 
Sheehan	E_m_03jd4n	6 
Thomas Edison	E_m_07bty	1 
Louisiana	E_m_0tl6d	5 
Qatar	E_m_029tr_	4 
Canton	E_m_01cd5l	5 
Hennepin County	E_m_0nhmw	1 
Ringo Starr	E_m_076d59	4 
Pacific Design Center	E_m_02pt6k9	1 
McCartney	E_m_03j24kf	1 
Maryland	E_m_0dzn7	2 
George Jones	E_m_01hb9p	1 
Kenya	E_m_05d49	2 
Sarasota	E_m_0rrt1	2 
John Rich	E_m_07wqk_	1 
BMG	E_m_01q940	1 
USA	E_m_09c7w0	1 
Kashmir	E_m_048bf_	3 
Mexico City	E_m_04sqj	1 
Pep Boys	E_m_030p_p	1 
Hewlett Packard	E_m_03mnk	1 
Ohio	E_m_01smm	4 
Newcastle	E_m_0j7ng	1 
George Bush	E_m_09b6zr	2 
South Dakota	E_m_0_rwf	4 
New Brunswick	E_m_074r0	2 
Hawaii	E_m_03gh4	1 
Laguna Beach	E_m_048wfw	1 
Manchester	E_m_0kqb0	2 
New York Police Department	E_m_01lvn4	1 
Johnny Cash	E_m_04w8rf	4 
Jeff Daniels	E_m_0372kf	1 
Fonda	E_m_07hkd	4 
LeAnn Rimes	E_m_07s61nv	2 
Wellington	E_m_0853g	1 
Coppola	E_m_01_f_5	5 
Jackman	E_m_05r751	2 
Barbara Streisand	E_m_03f2_rc	1 
Green Party	E_m_07k5l	1 
Nebraska	E_m_0chrx	3 
Slovenia	E_m_06t8v	1 
Donald Trump	E_m_0429hq	4 
TIME Magazine	E_m_07s52	1 
Gwen Stefani	E_m_01n9zh9	5 
Ivory Coast	E_m_0fv4v	1 
Korea	E_m_06qd3	2 
Thomas Jefferson	E_m_07cbs	1 
NSA	E_m_05htt	1 
Poland	E_m_05qhw	1 
Qatar	E_m_046zk0	5 
Ferndale	E_m_0nr3p	1 
St Louis	E_m_01n579	2 
Indiana University	E_m_01qrb2	1 
Duisburg	E_m_0ps1q	1 
McCartney	E_m_01f761	3 
Maryland	E_m_0tt6k	3 
George Jones	E_m_01d67x	3 
Rangoon	E_m_0fs54	1 
Sarasota	E_m_0rrvf	3 
John Rich	E_m_01qj8sj	2 
BMG	E_m_01kpth	2 
USA	E_m_0fw2y	2 
Kashmir	E_m_0djgt	8 
Mark Wills	E_m_01m3cwg	1 
Georgia	E_m_0d0kn	5 
MGM	E_m_0g1rw	1 
New Line Cinema	E_m_024rgt	1 
Newcastle	E_m_0fvly	6 
George Bush	E_m_0193q3	3 
Dolly Parton	E_m_02f1c	1 
New Brunswick	E_m_02w70	4 
Hawaii	E_m_09wyd	5 
Lynwood	E_m_0r0ls	1 
Manchester	E_m_01nhwy	4 
Nepal	E_m_016zwt	1 
Johnny Cash	E_m_098bm9	5 
Rob Marshall	E_m_02hc7q	1 
Fonda	E_m_0cj8x	6 
LeAnn Rimes	E_m_02vp0p6	3 
Wellington	E_m_02c4s	2 
Merle Haggard	E_m_01ww2fs	1 
Jackman	E_m_03nsp7q	5 
Barbara Streisand	E_m_01zg98	4 
Charlie Swift	E_m_0c80nx	1 
Nebraska	E_m_04gxf	4 
Slovenia	E_m_03ys48	4 
Donald Trump	E_m_0dzqp5	5 
Bruce Campbell	E_m_01h8f	1 
Sasha	E_m_01w8s4d	1 
Ivory Coast	E_m_04ddyt	4 
Korea	E_m_05b7q	3 
Thomas Jefferson	E_m_0px8y	2 
Peace Corps	E_m_019574	1 
Venice	E_m_07_pf	1 
VA	E_m_07z1m	1 
Neil Gaimen	E_m_05jm7	1 
New Brunswick	E_m_0xpp5	6 
Lansing	E_m_04pry	1 
Oxford	E_m_05l5n	1 
Woody Allen	E_m_081lh	1 
Nepal	E_m_04cx5	3 
Reliance Industries	E_m_0242c6	1 
Saddam Hussain	E_m_079dy	1 
Terracotta Army	E_m_0131pq	1 
LeAnn Rimes	E_m_06xt6v	4 
HOLLYWOOD	E_m_050ctv	2 
Merle Haggard	E_m_01jpfr8	3 
John Gibson	E_m_04myhq	1 
Sanford	E_m_02c6ck	1 
SANTA CLARITA	E_m_0fl3w4	1 
Stella	E_m_06b7_b	1 
Amy Goodman	E_m_020m38	1 
Ed Zwick	E_m_04g3p5	1 
Chad Johnson	E_m_03tnlt	1 
Sao Paulo	E_m_022pfm	1 
FAA	E_m_02_hj	1 
Korea	E_m_02hwhyv	5 
Thomas Jefferson	E_m_07cbs	3 
Knowles	E_m_01mpq7s	1 
Delisha Thomas	E_m_02pj_7x	1 
World Health Organisation	E_m_0840w	1 
Neil Gaimen	E_m_05hjxf	4 
Geneva	E_m_03902	1 
Duisburg	E_m_03c_t05	3 
McCartney	E_m_01wk4d2	4 
Shabazz	E_m_02z_zj	5 
Chinese Foreign Ministry	E_m_0c5lv5	1 
Jonathan Edwards	E_m_0dpv5	1 
Sarasota	E_m_0rry7	4 
John Rich	E_m_01hk70n	3 
Democratic Party	E_m_0d075m	1 
Balewa Muhammed	E_m_02z0ckz	1 
Baluchistan	E_m_0cbjfh	3 
Mark Wills	E_m_03yfwjb	3 
Pam Anderson	E_m_05r5w	1 
Bobby Fischer	E_m_06k9jc	1 
Order and Justice Party	E_m_02kzyq	7 
Zac	E_m_06wm0z	1 
George Bush	E_m_04g8d	5 
Dolly Parton	E_m_02s9k_	3 
Sears	E_m_01pkvx	1 
Jerry Springer	E_m_01v0432	1 
Oxford	E_m_07tgn	2 
Woody Allen	E_m_01tzw_	3 
Nepal	E_m_02rhmtd	5 
Verizon	E_m_07_dn	1 
Saddam Hussain	E_m_01c3y8	3 
Pittsburgh	E_m_068p2	1 
HDFC	E_m_025tzgk	1 
HOLLYWOOD	E_m_035zpq	4 
Vanilla Ice	E_m_01vxqyl	1 
Jessica Simpson	E_m_0c7xjb	1 
Carnoustie	E_m_07gv8l	1 
Austin	E_m_0vzm	1 
Stella	E_m_071mw	2 
Chris Breezy	E_m_07ss8_	2 
Jordin	E_m_09k2t1	1 
Chad Johnson	E_m_03tnlt	2 
Cyndi	E_m_01wf86y	1 
Lehman Brothers Japan	E_m_03lplr	1 
Korea	E_m_048n7	6 
Thomas Jefferson	E_m_02z_j3	4 
Liberal Constitutional Party	E_m_02439x	1 
Boston College	E_m_01jsk6	1 
Justin Timberlake	E_m_0j1yf	1 
JP Morgan Chase	E_m_01hlwv	1 
MSN	E_m_0198jf	1 
Duisburg	E_m_09ggxl	6 
McCartney	E_m_01dwcv	5 
Ku Klux Klan	E_m_048qr	1 
Chinese Foreign Ministry	E_m_02626pc	2 
Continental Airlines	E_m_0sy5v	1 
Zurich	E_m_08966	1 
John Rich	E_m_02rqtz2	4 
Democratic Party	E_m_07wbk	2 
George Burns	E_m_01t94_1	1 
Baluchistan	E_m_0fkf9j	5 
Mark Wills	E_m_03yfv1f	4 
Pam Anderson	E_m_05zhsb	2 
Bobby Fischer	E_m_0h09p	2 
PVDSA	E_m_04gnr5	1 
Georgia Tech	E_m_0f1nl	1 
George Bush	E_m_034ls	6 
Dolly Parton	E_m_01l1_1	5 
Suzuki	E_m_02ws0w	1 
Jerry Springer	E_m_0zxgh	6 
Glenn Beck	E_m_0264n4	1 
Woody Allen	E_m_01cpqk	4 
Nepal	E_m_05bwc	6 
Jamal Williams	E_m_09gjr4	1 
Saddam Hussain	E_m_023ygx	9 
Pittsburgh	E_m_01jssp	3 
Washington Times	E_m_07qhs	1 
Dublin	E_m_02cft	1 
UC Irvine	E_m_0c5x_	1 
Ken Starr	E_m_0grkx	1 
Fulton	E_m_06j4s	1 
Nepal	E_m_0h0t4	7 
LaSalle Bank Corp	E_m_07k6g8	1 
Berkshire Hathaway	E_m_01tmng	1 
Douglas Adams	E_m_0282x	1 
Larry Craig	E_m_021pfw	1 
Bill Gates	E_m_017nt	1 
The Associated Press	E_m_0cv_2	1 
Carnoustie	E_m_03kb5r	2 
Austin	E_m_0mpzm	2 
The Times	E_m_09rkd	1 
Chris Breezy	E_m_01rph40	3 
Jordin	E_m_09k2t1	3 
Chad Johnson	E_m_049d_	4 
Cyndi	E_m_0bgjq1	5 
Lehman Brothers Japan	E_m_078t6w	3 
Ore	E_m_02npvl	6 
Armani Exchange	E_m_03wr6g	1 
Clarisa Fernandez	E_m_0ddvyt	1 
British Broadcasting Corporation	E_m_0g5lhl7	1 
Justin Timberlake	E_m_0320jz	3 
TIA	E_m_07s82	1 
Malaga	E_m_01978d	1 
Pisco	E_m_02wprs	3 
McCartney	E_m_01j7tc9	6 
WalMart	E_m_0841v	1 
NY Times	E_m_07k2d	1 
IDBI Bank	E_m_090whv	1 
DeGeneres	E_m_01gbbz	1 
Kid Rock	E_m_01vw20_	1 
Jokela	E_m_03cv7d7	1 
George Burns	E_m_01whz6_	2 
Brian Williams	E_m_030p0z	1 
Seth Rogan	E_m_05txrz	1 
Pam Anderson	E_m_08drs2	3 
Bobby Fischer	E_m_02rhjj	7 
Chen Shu-bian	E_m_0fbn3	1 
Bob Hope	E_m_015cbq	1 
General Electric	E_m_03bnb	1 
Judy Shepard	E_m_0nx9_	6 
HAARP	E_m_07jyq	2 
Maruti Udyog	E_m_042ggk	1 
Willie Nelson	E_m_0137n0	1 
Preston	E_m_0m7dd	1 
Nepal	E_m_01tgny	8 
Camilla al Fayed	E_m_051g0	1 
National Science Foundation	E_m_014psl	1 
Petra Nemcova	E_m_033zwr	1 
State Department	E_m_07vsl	1 
Bill Gates	E_m_0dmp4	4 
National Students Union	E_m_01d62s	2 
Davos	E_m_0pbgk	1 
Austin	E_m_01mz2x	4 
Fort Worth	E_m_0f2s6	1 
Leo DiCaprio	E_m_0dvmd	1 
Jordin	E_m_0bb85cr	5 
Chad Johnson	E_m_02zdgb	6 
Cyndi	E_m_04kcym	6 
PT Excelcomindo Pratama	E_m_047rwn1	1 
Alan Jackson	E_m_016c8l	1 
North Atlantic Treaty Organization	E_m_059dn	1 
Bago	E_m_06ncrh	2 
UC	E_m_07vgd	1 
Justin Timberlake	E_m_01mzt36	4 
San Jose	E_m_0f04v	1 
Charles Larson	E_m_0kt7y8	2 
HANOVER	E_m_03pbf	1 
FICO	E_m_02cgrf	1 
Heidi Klum	E_m_01pctb	1 
UN Security Council	E_m_07vnr	1 
Colorado City	E_m_0qpvx	1 
DeGeneres	E_m_01pcz9	2 
Kid Rock	E_m_01ws5ht	4 
Brown Institute	E_m_04_blz	1 
George Burns	E_m_07z81x	3 
Brian Williams	E_m_0djc_l	2 
Seth Rogan	E_m_02825nf	4 
Pam Anderson	E_m_0fp0mk	4 
HAARP	E_m_03cnf_5	6 
National Union of Mine Workers	E_m_025n0_	1 
Willie Nelson	E_m_07s7kjg	2 
Preston	E_m_09ybgf	3 
Nepal	E_m_02wx1kv	9 
Wesleyan University	E_m_01k2wn	1 
National Union of Mine Workers	E_m_025n0_	2 
Willie Nelson	E_m_04hw0c	5 
Riyadh	E_m_0dlm_	1 
Bengkulu	E_m_02bdkx	1 
US Senate	E_m_07t58	1 
Guinea	E_m_03676	1 
NWF	E_m_04z44v	1 
Bill Gates	E_m_05tkm	5 
Orient-Express	E_m_0c2h62	2 
Davos	E_m_027rmps	4 
MILAN	E_m_0947l	1 
National Union of Mine Workers	E_m_0djx71	3 
Reserve Bank	E_m_02gzw1	1 
MILAN	E_m_011v3	6 
North Waziristan Agency	E_m_048z8c	1 
Led Zeppelin	E_m_04k05	1 
Bengkulu	E_m_0gc8cf	2 
Washington University	E_m_0g2jl	1 
Guinea	E_m_0fn8p	3 
Armenia	E_m_0jgx	1 
Charlie Dressen	E_m_06v265	1 
Led Zeppelin	E_m_015pvx	3 
Bengkulu	E_m_02hxvm1	3 
COLUMBUS	E_m_01pwz	1 
Guinea	E_m_02kcz	4 
Bill Gates	E_m_027z0k	7 
Orient-Express	E_m_015m8_	3 
Davos	E_m_0174w5	7 
UCLA Medical Center	E_m_04fghh	1 
Leo DiCaprio	E_m_04kdfm	3 
Mayawati	E_m_02psg0	1 
Warren Buffett	E_m_01d_ys	1 
Gordon Brown	E_m_03f77	1 
Sinaloa	E_m_01gfkk	1 
Alan Jackson	E_m_03cm7hm	3 
North Atlantic Treaty Organization	E_m_05j8g	5 
Norman	E_m_0z4_0	1 
Missouri	E_m_06wxw	2 
Justin Timberlake	E_m_05n3l7	5 
Johns Hopkins	E_m_09kvv	1 
George Town	E_m_01c60h	1 
HANOVER	E_m_013_6w	5 
Goldman	E_m_01xdn1	1 
Mark Twain	E_m_014635	1 
Nazareth	E_m_05fz3	1 
Rolling Thunder	E_m_01gy3j	1 
DeGeneres	E_m_0528kc	3 
Kid Rock	E_m_01kcl94	5 
Armenia	E_m_0xrg	5 
Ybor City	E_m_03cbsk	1 
Led Zeppelin	E_m_0pkyh	4 
Led Zeppelin	E_m_01vsyg9	5 
COLUMBUS	E_m_0wfd3	6 
Manhasset	E_m_0y2r_	1 
Mana	E_m_03b77h	6 
Bill Gates	E_m_010rmb	9 
Bruce Lee	E_m_099d4	1 
Bruce Lee	E_m_01dkgz	2 
UMNO	E_m_01__z0	1 
New York Stock Exchange	E_m_05drh	1 
Environmental Protection Agency	E_m_0g0lh	1 
Warren Buffett	E_m_0d2gsm	3 
Cecilia Malmstrom	E_m_054w2k	1 
Bruce Lee	E_m_0fdb3	3 
Oman Telecommunications Company	E_m_02686nz	1 
Robert Menendez	E_m_033d3p	1 
Galilee	E_m_0j1t3	2 
Warren Buffett	E_m_03cjb43	5 
Haren	E_m_04qzsg	2 
Alan Jackson	E_m_0drwgh	4 
Britney Spears	E_m_015f7	1 
Bruce Lee	E_m_05_pzw	4 
Chester	E_m_01423b	1 
PAKISTAN	E_m_05sb1	1 
Hungary	E_m_03gj2	1 
Warren Buffett	E_m_03llg9	6 
Marvel Entertainment Inc.	E_m_0c_j5d	1 
Alan Jackson	E_m_02q34zp	5 
Britney Spears	E_m_03cn3v1	3 
Bob Dole	E_m_0fhkx	1 
Paul Walker	E_m_01kgxf	1 
National Transportation Board	E_m_05h31	1 
George Town	E_m_015806	2 
Bruce Lee	E_m_02rzb	5 
Grand National	E_m_02r7lj6	6 
Christine Todd Whitman	E_m_019qv6	1 
Rachael Ray	E_m_031618	1 
Hungary	E_m_01zd7d	4 
Secret Service	E_m_0fynw	1 
Public Security Police	E_m_01ncvk	1 
Angelina Jolie	E_m_0f4vbz	1 
Britney Spears	E_m_01hm5fk	4 
Bisher al-Rawi	E_m_0803h9	1 
World Trade Organisation	E_m_085h1	1 
Tom Coburn	E_m_03wnjr	1 
Free Trade Union	E_m_07gkc2	2 
Ostrava	E_m_07g4fk	6 
Carton Carroll	E_m_02q868l	1 
Angelina Jolie	E_m_046qq	2 
Britney Spears	E_m_01hm56_	5 
Cesaria Evora	E_m_0j_gr	1 
Free Trade Union	E_m_095q8	5 
Belize City	E_m_0177xm	1 
Carton Carroll	E_m_02ps_y6	2 
Angelina Jolie	E_m_0c6qh	3 
Chrysler	E_m_01_bp	1 
Scarsdale	E_m_01rkbc	1 
BZ	E_m_03y2d0	1 
Santos	E_m_019lxm	1 
Angelina Jolie	E_m_01mqgf	4 
Sherpa	E_m_01gr8h	1 
Santos	E_m_027j0rt	4 
Angelina Jolie	E_m_01fh9	5 
Santos	E_m_03nw8m	5 
Mongolia	E_m_04w8f	1 
DT	E_m_0fpnjr	6 
Mark Twain	E_m_03q5b	4 
Nazareth	E_m_01vtkx	3 
Oklahoma	E_m_0fvzg	2 
Washington DC	E_m_0rh6k	1 
Al Qaeda	E_m_0v74	1 
Nazareth	E_m_02t5l1	6 
DeGeneres	E_m_043x92	4 
Daily Mail	E_m_0180v2	1 
George Burns	E_m_06rj2f	5 
Brian Williams	E_m_0t67h	3 
Seth Rogan	E_m_047m6mv	5 
Pam Anderson	E_m_0c61rf	5 
Oklahoma	E_m_0k92j	3 
Oklahoma	E_m_013kcv	5 
Saks Fifth Avenue	E_m_079bt	1 
Nazareth	E_m_01jkmfs	8 
DeGeneres	E_m_01vhb0	5 
Nivea Hamilton	E_m_01mv4h9	1 
Marc Anthony	E_m_01wv9p	1 
Brian Williams	E_m_065lsm	4 
Jerusalem Post	E_m_01978x	1 
Mike Russell	E_m_03bzbx	1 
William Shakespeare	E_m_081k8	1 
Joe Biden	E_m_012gx2	1 
Keith Anderson	E_m_07cgrf	1 
Tamil Tigers	E_m_04q9w	1 
US Airways	E_m_01qmg5	1 
Nazareth	E_m_08cgd0	10 
KROQ	E_m_017drb	1 
USC	E_m_07vwp	1 
Marc Anthony	E_m_02rrrp1	3 
Brian Williams	E_m_0dknp2	6 
Dartmouth	E_m_02bqy	1 
Tamil Tigers	E_m_029ccy	2 
C. Michael Foale	E_m_02cwy9	1 
Teheran	E_m_0ftlx	1 
Refoundation Communists	E_m_01zyx7	1 
Tustin	E_m_0r2q1	1 
Marc Anthony	E_m_02pr1v2	5 
FDIC	E_m_015wpt	1 
Liverpool	E_m_04lh6	1 
William Shakespeare	E_m_0bdc4	5 
Stephen King	E_m_06pnq	1 
Johannesburg	E_m_0g284	1 
Tamil Tigers	E_m_07qct	5 
Mobile	E_m_058cm	1 
Teheran	E_m_0359x4	3 
Matthaeus	E_m_01ttk9t	1 
NLF	E_m_0hw29	1 
Magnum	E_m_06rfd4	2 
Teheran	E_m_06sdvc	4 
NLF	E_m_0hw29	2 
Magnum	E_m_03ylyv	4 
Teheran	E_m_01ct02	6 
Lily Allen	E_m_0czkbt	1 
Randalls	E_m_05_94s	1 
Liverpool	E_m_04ltf	2 
DMK	E_m_024z18	1 
Stephen King	E_m_07j6g	4 
Corey Johnson	E_m_06znt5	1 
Wainwright	E_m_01hsrn	2 
Magnum	E_m_02mc3x	5 
Teheran	E_m_02vr30	9 
Lily Allen	E_m_04cy6hp	4 
Chen Pao-chung	E_m_04md0g	1 
BUFFALO	E_m_019fh	1 
Connecticut	E_m_01x73	1 
Travis Tritt	E_m_01k_r5b	1 
CAA	E_m_020sn8	1 
MTR	E_m_01nj0j	1 
MTR	E_m_046w7v	5 
Korea National Oil Corp	E_m_03h2z4h	1 
O2	E_m_047t9qn	3 
Montreal	E_m_052p7	1 
Butte	E_m_0c3jhm	2 
Connecticut	E_m_0f1sm	4 
Travis Tritt	E_m_01k_r48	3 
National Development and Reform Committee	E_m_02qdypp	1 
ARGENTINA	E_m_0jgd	1 
Lyon	E_m_0dprg	1 
O2	E_m_03fhtm	4 
Montreal	E_m_05fyrr	2 
Butte	E_m_01m2v2	4 
Connecticut	E_m_0m2fr	5 
Borders	E_m_0mdv8	1 
National Development and Reform Committee	E_m_02qdypp	6 
ARGENTINA	E_m_02bh_v	2 
Lyon	E_m_03w7kx	2 
Kunduz	E_m_01g8_p	1 
Montreal	E_m_0jplb	3 
ARGENTINA	E_m_01ly5m	4 
Managua	E_m_0fqbf	1 
Managua	E_m_02y8v7	2 
Montreal	E_m_0fk8v	5 
Richmond	E_m_0dzt9	1 
HONIARA	E_m_09_ryj	6 
Matt Farrell	E_m_07cjqy	1 
Guayaquil	E_m_01fknt	1 
\.



--
-- Greenplum Database database dump complete
--

